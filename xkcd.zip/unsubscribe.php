<?php
$co = mysqli_connect("localhost", "u623876688_xkcd", "Xkcd@123", "u623876688_xkcd");
if(isset($_GET['email'])){
$email = mysqli_real_escape_string($co,$_POST['email']);
mysqli_query($co,"UPDATE `user` SET `subscribe`=1 WHERE `email`='".$email."'");
echo "We are sorry. You don't like our mails";
}