<?php
$co = mysqli_connect("localhost", "u623876688_xkcd", "Xkcd@123", "u623876688_xkcd");
if(isset($_POST['email']) and isset($_POST['otp'])){
$email = mysqli_real_escape_string($co,$_POST['email']);
$otp = mysqli_real_escape_string($co,$_POST['otp']);
$a = mysqli_query($co,"SELECT * FROM `user` WHERE `email`='".$email."' AND `otp`='$otp'");
if(mysqli_num_rows($a) == 1){
mysqli_query($co,"UPDATE `user` SET `subscribe`=1 WHERE `email`='".$email."' AND `otp`='$otp'");
$url = 'https://c.xkcd.com/random/comic/';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$html = curl_exec($ch);
$redirectedUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
curl_close($ch);
$url2 = $redirectedUrl.'info.0.json';
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => $url2,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));
$response = curl_exec($curl);
curl_close($curl);
$a = json_decode($response, true);
$b = $a['img'];
$to = $email;
$from = '<no-reply no-reply@demowebsites.co.in>'; 
$fromName = 'no-reply'; 
       $subject = 'XKCD ';
       $message = 'You can unsubscribe from our mail list <a href="http://demowebsites.co.in/xkcd/unsubscribe.php?email='.$email.'">unsubscribe</a>';
       $file = $b;
       $content = chunk_split(base64_encode(file_get_contents($file)));
       $uid = md5(uniqid(time()));
        $header = "From: ".$from."\r\n";
       $header .= "Reply-To: ".$replyto. "\r\n";
       $header .= "MIME-Version: 1.0\r\n";
       $header .="Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n";
       $header .="This is a multi-part message in MIME format.\r\n";
       $header .= "--".$uid."\r\n";
       $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
       $header .= "Content-Transfer-Encoding: 7bit\r\n";
       $header .= $message. "\r\n";
       $header .= "--".$uid."\r\n";
       $header .= "Content-Type: ".'png'."; name=\"".'xkcd.png'."\"\r\n";
       $header .= "Content-Transfer-Encoding: base64\r\n";
       $header .= "Content-Disposition: attachment; filename=\"".$file_name."\"\r\n";
       $header .= $content."\r\n";  //chucked up 64 encoded attch
       if(mail($to, $subject, $message, $header)) {
    //   echo "success";
       }else {
        //   echo "fail";
        //   echo error_get_last()['message'];
       }
}else{
    $mess = "Email and OTP not match";
}
}elseif(isset($_POST['email'])){
$email = mysqli_real_escape_string($co,$_POST['email']);
$a = mysqli_query($co,"SELECT * FROM `user` WHERE `email`='".$email."'");
if(mysqli_num_rows($a) == 0){
$otp = rand(1000,9999);
$insert = mysqli_query($co,"INSERT INTO `user`(`email`, `otp`) VALUES ('$email','$otp')");

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <no-reply no-reply@demowebsites.co.in>' . "\r\n";
$to=$email;
$message="Your OTP is ".$otp;
mail($to,"Registration",$message,$headers);
}else{
    $mess = "Email Already Exits";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>XKCD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #f8f9fa;
   color: black;
   text-align: center;
}
</style>
</head>
<body>
<div class="container-fluid">
<nav class="navbar navbar-expand-sm bg-light navbar-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="logo.png" style="height:45px;"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://c.xkcd.com/random/comic/">Random comic</a>
        </li> 
      </ul>
    </div>
  </div>
</nav>
<div class="card">
<div class="card-header">
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner" style="height:230px;">
    <div class="carousel-item active">
      <img src="https://imgs.xkcd.com/comics/lithium_batteries.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://imgs.xkcd.com/comics/new_sports_system.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://imgs.xkcd.com/comics/stargazing.png" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

</div>
<div class="card-body">
    <h2>Subscribe to our mailing list for get comic updates</h2>
  <form method="post">
    <div class="form-group">
      <?php if(isset($mess)){?><label style="color:red;" for="email"><?=$mess?></label><br><?php }?>
      <?php if(!isset($insert)){?><label for="email">Enter your email address:</label><?php }?>
      <input type="<?php if(isset($insert)){?>hidden<?php }else{?>email<?php }?>" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php if(isset($email)){ echo $email;}?>">
    </div>
    <?php if(isset($insert)){?>
    <div class="form-group">
      <label for="otp">OTP:</label>
      <input type="otp" class="form-control" id="otp" placeholder="Enter otp" name="otp">
    </div>
    <?php }?><br>
    <button type="submit" class="btn btn-success">Submit</button>
  </form>
</div>
</div>
</div>
<div style="width:100%;height:20px;"></div>
<div class="footer">
  <div class="card">
  <div class="card-header">
        <p>Created and design by The brandsdoor</p>
  </div>
</div>
</div>
</div>
</body>
</html>